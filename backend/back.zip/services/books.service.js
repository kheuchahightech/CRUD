const Book = require('../models/Book');
const AppError = require('../utils/appError');
const logger = require('../utils/logger');

// Création d'un livre
exports.createBook = async (bookData, userId) => {
  try {
    // Vérification de l'ISBN unique
    const existingBook = await Book.findOne({ isbn: bookData.isbn });
    if (existingBook) {
      throw new AppError('Un livre avec cet ISBN existe déjà', 400);
    }

    // Création du livre
    const book = await Book.create({ ...bookData, userId });
    return book;
  } catch (error) {
    logger.error(`Erreur de création de livre: ${error.message}`);
    throw error;
  }
};

// Récupération des livres avec filtres
exports.getBooks = async (userId, filters = {}) => {
  try {
    const { search, category, sort, page = 1, limit = 10 } = filters;
    
    // Construction de la requête
    let query = { userId };
    
    // Filtre de recherche
    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { author: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ];
    }
    
    // Filtre par catégorie
    if (category) {
      query.category = category;
    }
    
    // Calcul de la pagination
    const skip = (page - 1) * limit;
    
    // Exécution de la requête
    const books = await Book.find(query)
      .sort(sort || '-createdAt')
      .skip(skip)
      .limit(limit);
    
    // Calcul du total pour la pagination
    const total = await Book.countDocuments(query);
    
    return {
      success: true,
      count: books.length,
      total,
      page,
      pages: Math.ceil(total / limit),
      data: books
    };
  } catch (error) {
    logger.error(`Erreur de récupération des livres: ${error.message}`);
    throw error;
  }
};

// Mise à jour d'un livre
exports.updateBook = async (bookId, userId, updateData) => {
  try {
    const book = await Book.findOneAndUpdate(
      { _id: bookId, userId },
      updateData,
      { new: true, runValidators: true }
    );
    
    if (!book) {
      throw new AppError('Livre non trouvé ou non autorisé', 404);
    }
    
    return book;
  } catch (error) {
    logger.error(`Erreur de mise à jour du livre: ${error.message}`);
    throw error;
  }
};

// Suppression d'un livre
exports.deleteBook = async (bookId, userId) => {
  try {
    const book = await Book.findOneAndDelete({ _id: bookId, userId });
    
    if (!book) {
      throw new AppError('Livre non trouvé ou non autorisé', 404);
    }
    
    return { success: true };
  } catch (error) {
    logger.error(`Erreur de suppression du livre: ${error.message}`);
    throw error;
  }
};