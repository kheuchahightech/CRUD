const User = require('../models/User');
const jwt = require('jsonwebtoken');
const logger = require('../utils/logger');
const AppError = require('../utils/appError');
const { promisify } = require('util');

// Génération de token
const signToken = (userId) => {
  return jwt.sign({ userId }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN
  });
};

// Création et envoi du token
const createSendToken = (user, statusCode, res) => {
  const token = signToken(user._id);
  
  // Configuration du cookie
  const cookieOptions = {
    expires: new Date(
      Date.now() + process.env.JWT_COOKIE_EXPIRES_IN * 24 * 60 * 60 * 1000
    ),
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production'
  };

  // Envoi du cookie
  res.cookie('token', token, cookieOptions);

  // Retrait du mot de passe de la réponse
  user.password = undefined;

  res.status(statusCode).json({
    success: true,
    token,
    data: {
      user
    }
  });
};

// Inscription
exports.register = async (userData) => {
  try {
    // Vérification des doublons
    const existingUser = await User.findOne({ 
      $or: [
        { email: userData.email },
        { username: userData.username }
      ] 
    });

    if (existingUser) {
      throw new AppError('Cet email ou nom d\'utilisateur est déjà utilisé', 400);
    }

    // Création de l'utilisateur
    const newUser = await User.create(userData);

    return newUser;
  } catch (error) {
    logger.error(`Erreur d'inscription: ${error.message}`);
    throw error;
  }
};

// Connexion
exports.login = async (email, password) => {
  try {
    // 1) Vérifier si l'email et le mot de passe existent
    if (!email || !password) {
      throw new AppError('Veuillez fournir un email et un mot de passe', 400);
    }

    // 2) Vérifier si l'utilisateur existe et si le mot de passe est correct
    const user = await User.findOne({ email }).select('+password');

    if (!user || !(await user.comparePassword(password, user.password))) {
      throw new AppError('Email ou mot de passe incorrect', 401);
    }

    return user;
  } catch (error) {
    logger.error(`Erreur de connexion: ${error.message}`);
    throw error;
  }
};

// Vérification du token
exports.protect = async (token) => {
  try {
    // 1) Vérification du token
    if (!token) {
      throw new AppError('Vous n\'êtes pas connecté. Veuillez vous connecter pour accéder à cette ressource.', 401);
    }

    // 2) Vérification de la validité du token
    const decoded = await promisify(jwt.verify)(token, process.env.JWT_SECRET);

    // 3) Vérification que l'utilisateur existe toujours
    const currentUser = await User.findById(decoded.userId);
    if (!currentUser) {
      throw new AppError('L\'utilisateur associé à ce token n\'existe plus.', 401);
    }

    return currentUser;
  } catch (error) {
    logger.error(`Erreur de vérification du token: ${error.message}`);
    throw error;
  }
};