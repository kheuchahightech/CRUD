const jwt = require('jsonwebtoken');
const User = require('../models/User');
const logger = require('../utils/logger');

// Protection des routes
exports.protect = async (req, res, next) => {
  let token;
  
  // 1. Vérification du token
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  } else if (req.cookies?.token) {
    token = req.cookies.token;
  }

  if (!token) {
    logger.warn('Tentative d\'accès non autorisée - Token manquant');
    return res.status(401).json({ 
      success: false,
      error: 'Accès non autorisé. Veuillez vous connecter.' 
    });
  }

  try {
    // 2. Vérification du token JWT
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // 3. Vérification que l'utilisateur existe toujours
    const currentUser = await User.findById(decoded.userId);
    if (!currentUser) {
      logger.warn(`Token valide mais utilisateur introuvable - ID: ${decoded.userId}`);
      return res.status(401).json({ 
        success: false,
        error: 'L\'utilisateur associé à ce token n\'existe plus.' 
      });
    }

    // 4. Vérification si le mot de passe a changé après l'émission du token
    if (currentUser.changedPasswordAfter(decoded.iat)) {
      logger.warn('Token invalide - Mot de passe modifié récemment');
      return res.status(401).json({ 
        success: false,
        error: 'Votre mot de passe a été modifié récemment. Veuillez vous reconnecter.' 
      });
    }

    // Ajout de l'utilisateur à la requête
    req.user = currentUser;
    next();
  } catch (error) {
    logger.error(`Erreur d'authentification: ${error.message}`);
    res.status(401).json({ 
      success: false,
      error: 'Session invalide. Veuillez vous reconnecter.' 
    });
  }
};

// Gestion des rôles
exports.restrictTo = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      logger.warn(`Tentative d'accès non autorisée - Rôle: ${req.user.role}`);
      return res.status(403).json({ 
        success: false,
        error: 'Vous n\'avez pas les droits nécessaires pour cette action' 
      });
    }
    next();
  };
};