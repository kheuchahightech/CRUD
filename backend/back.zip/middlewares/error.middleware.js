const logger = require('../utils/logger');
const AppError = require('../utils/appError');

// Gestion des erreurs de développement
const sendErrorDev = (err, res) => {
  logger.error(`ERROR: ${err.message}`);
  res.status(err.statusCode).json({
    success: false,
    error: err,
    message: err.message,
    stack: err.stack
  });
};

// Gestion des erreurs de production
const sendErrorProd = (err, res) => {
  // Erreurs opérationnelles (que l'on connaît)
  if (err.isOperational) {
    res.status(err.statusCode).json({
      success: false,
      message: err.message
    });
  } 
  // Erreurs de programmation ou inconnues (ne pas divulguer les détails)
  else {
    logger.error(`ERROR 💥: ${err}`);
    res.status(500).json({
      success: false,
      message: 'Une erreur est survenue!'
    });
  }
};

// Gestion des erreurs MongoDB
const handleMongoError = (err) => {
  let error = { ...err };
  error.message = err.message;

  // Erreur de duplication (unique)
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue)[0];
    const message = `${field} est déjà utilisé. Veuillez en choisir un autre.`;
    return new AppError(message, 400);
  }

  // Erreur de validation
  if (err.name === 'ValidationError') {
    const errors = Object.values(err.errors).map(el => el.message);
    const message = `Données invalides: ${errors.join('. ')}`;
    return new AppError(message, 400);
  }

  // Erreur de Cast (ObjectId invalide)
  if (err.name === 'CastError') {
    const message = `Ressource introuvable avec l'ID: ${err.value}`;
    return new AppError(message, 404);
  }

  return error;
};

// Middleware principal
module.exports = (err, req, res, next) => {
  err.statusCode = err.statusCode || 500;
  
  let error = handleMongoError(err);

  if (process.env.NODE_ENV === 'development') {
    sendErrorDev(error, res);
  } else if (process.env.NODE_ENV === 'production') {
    sendErrorProd(error, res);
  }
};