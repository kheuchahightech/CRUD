import express from 'express';
import {
  getBooks,
  getBook,
  createBook,
  updateBook,
  deleteBook,
  getBookCategories
} from '../controllers/bookController';
import { protect } from '../middlewares/auth.middleware';

const router = express.Router();

router.use(protect);

router.route('/')
  .get(getBooks)
  .post(createBook);

router.route('/categories')
  .get(getBookCategories);

router.route('/:id')
  .get(getBook)
  .put(updateBook)
  .delete(deleteBook);

export default router;