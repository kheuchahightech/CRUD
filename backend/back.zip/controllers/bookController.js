import { Request, Response } from 'express';
import * as bookService from '../src/services/books.service';
import logger from '../src/utils/helpers';

export const getBooks = async (req: Request, res: Response) => {
  try {
    const { search, category } = req.query;
    const books = await bookService.getBooks(
      req.user.id,
      search as string | undefined,
      category as string | undefined
    );
    
    res.status(200).json({
      success: true,
      count: books.length,
      data: books
    });
  } catch (error: any) {
    logger.error(error.message);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
};

export const getBook = async (req: Request, res: Response) => {
  try {
    const book = await bookService.getBookById(req.params.id, req.user.id);
    
    res.status(200).json({
      success: true,
      data: book
    });
  } catch (error: any) {
    logger.error(error.message);
    res.status(404).json({
      success: false,
      error: error.message
    });
  }
};

export const createBook = async (req: Request, res: Response) => {
  try {
    const book = await bookService.createBook(req.body, req.user.id);
    
    res.status(201).json({
      success: true,
      data: book
    });
  } catch (error: any) {
    logger.error(error.message);
    res.status(400).json({
      success: false,
      error: error.message
    });
  }
};

export const updateBook = async (req: Request, res: Response) => {
  try {
    const book = await bookService.updateBook(req.params.id, req.body, req.user.id);
    
    res.status(200).json({
      success: true,
      data: book
    });
  } catch (error: any) {
    logger.error(error.message);
    res.status(404).json({
      success: false,
      error: error.message
    });
  }
};

export const deleteBook = async (req: Request, res: Response) => {
  try {
    await bookService.deleteBook(req.params.id, req.user.id);
    
    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (error: any) {
    logger.error(error.message);
    res.status(404).json({
      success: false,
      error: error.message
    });
  }
};

export const getBookCategories = async (req: Request, res: Response) => {
  try {
    const categories = await bookService.getCategories(req.user.id);
    
    res.status(200).json({
      success: true,
      data: categories
    });
  } catch (error: any) {
    logger.error(error.message);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
};